import { Routes, Route } from 'react-router-dom';
import Landing from './routes/Landing';
import QRCheckIn from './routes/QRCheckIn';
import GuestCheckIn from './routes/GuestCheckIn';
import UploadPhoto from './routes/UploadPhoto';
import CheckInSuccess from './routes/CheckInSuccess';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/qr-checkin" element={<QRCheckIn />} />
      <Route path="/guest-checkin" element={<GuestCheckIn />} />
      <Route path="/upload-photo" element={<UploadPhoto />} />
      <Route path="/checkin-success" element={<CheckInSuccess />} />
    </Routes>
  );
}

export default App;
