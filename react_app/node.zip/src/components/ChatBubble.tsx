/* components/ChatBubble.tsx */
import { motion } from "framer-motion";

type ChatBubbleProps = { role: string; content: string };

const ChatBubble = ({ role, content }: ChatBubbleProps) => {
  const isUser = role === "user";
  const isSystem = role === "system";

  const bubbleBase = "whitespace-pre-line px-6 py-3 rounded-3xl shadow";
  const bubbleStyle = isUser
    ? "bg-indigo-600 text-white self-end"
    : isSystem
    ? "bg-gray-200 text-gray-600 self-center italic text-sm"
    : "bg-white text-gray-900 self-start";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`${bubbleBase} ${bubbleStyle} max-w-[75%] break-words`}
    >
      {content}
    </motion.div>
  );
};

export default ChatBubble;
