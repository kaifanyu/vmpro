import { useLocation } from 'react-router-dom';

const CheckInSuccess = () => {
  const location = useLocation();
  const visitorInfo = location.state?.visitorInfo || {};

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-tr from-green-100 to-white px-6 py-12">
      <div className="text-center space-y-6 max-w-xl">
        <h1 className="text-4xl font-bold text-green-600">You're All Set!</h1>
        <p className="text-xl text-gray-700">
          We've notified <strong>{visitorInfo.name}</strong> via{" "}
          <strong>{visitorInfo.email}</strong> to let them know you have arrived.
        </p>
        <p className="text-sm text-gray-500">
          Please wait in the lobby. Your host will be with you shortly.
        </p>
      </div>
    </div>
  );
};

export default CheckInSuccess;
