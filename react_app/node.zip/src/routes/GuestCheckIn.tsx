import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ChatBubble from '../components/ChatBubble';

const GuestCheckIn = () => {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Welcome. What is your full name?" }
  ]);
  const [input, setInput] = useState("");
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMsgs = [...messages, { role: 'user', content: input }];
    setMessages(newMsgs);
    setInput('');

    try {
      const res = await fetch('http://192.168.162.183:8080/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMsgs }),
      });

      const data = await res.json();
      setMessages([...newMsgs, { role: data.role, content: data.content }]);

      if (data.checkin_complete && data.data) {
        setTimeout(() => {
          navigate('/upload-photo', { state: { visitorInfo: data.data } });
        }, 1500);
      }

    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center bg-gray-50 min-h-screen p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-lg flex flex-col h-[90vh]">

        <header className="px-6 py-4 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-800 text-center">
            Guest Check-In Assistant
          </h1>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
          {messages.map((msg, i) => (
            <ChatBubble key={i} role={msg.role} content={msg.content} />
          ))}
          <div ref={chatEndRef} />
        </div>

        <footer className="px-4 py-3 border-t border-gray-200">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
              placeholder="Type your message..."
              className="flex-1 border border-gray-300 rounded-full px-4 py-2 focus:outline-none focus:ring focus:ring-indigo-200"
            />
            <button
              onClick={sendMessage}
              className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full px-5 py-2 transition"
            >
              Send
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default GuestCheckIn;
