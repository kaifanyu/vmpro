import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-gray-100 to-gray-200">
      {/* Header with logo */}
      <header className="flex items-center justify-between px-8 py-4">
        <img src="/logo.png" alt="UNIS Logo" className="h-10 w-auto" />
      </header>

      {/* Center content */}
      <main className="flex flex-col items-center justify-center px-4 text-center mt-12">
        <h1 className="text-5xl font-extrabold text-gray-800 leading-tight mb-6">
          Welcome to <span className="text-blue-600">UNIS</span> Check-In
        </h1>
        <p className="text-lg text-gray-600 max-w-md mb-10">
          Please select a check-in method below to continue.
        </p>

        <div className="flex flex-col space-y-4 w-full max-w-xs">
          <Button onClick={() => navigate('/qr-checkin')} className="w-full py-3 text-lg rounded-xl">
            📷 Check in with QR Code
          </Button>
          <Button onClick={() => navigate('/guest-checkin')} className="w-full py-3 text-lg rounded-xl">
            🙋 Guest Check In
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Landing;
