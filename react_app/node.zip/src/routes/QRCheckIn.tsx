import { useState, useRef, useEffect } from 'react';

const QRCheckIn = () => {
  const [qrFile, setQrFile] = useState<File | null>(null);
  const [qrPreviewUrl, setQrPreviewUrl] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [visitorInfo, setVisitorInfo] = useState<any>(null);
  const [message, setMessage] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      videoRef.current.play();
    }
  };

  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (canvas && video) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        if (blob) {
          setSelfie(new File([blob], 'selfie.jpg', { type: 'image/jpeg' }));
        }
      }, 'image/jpeg');
    }
  };

  const handleQRChange = (file: File | null) => {
    setQrFile(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setQrPreviewUrl(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setQrPreviewUrl(null);
    }
  };

  const handleUpload = async () => {
    //if (!qrFile || !selfie) {
      //setMessage("Both QR code and selfie are required.");
      //return;
    //}

    const formData = new FormData();
    formData.append("file", qrFile);
    //formData.append("selfie", selfie);

    const res = await fetch("http://192.168.162.183:8080/upload", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();
    if (res.ok) {
      setVisitorInfo(data);
    } else {
      setMessage(data.message || "Upload failed.");
    }
  };

  if (visitorInfo) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-tr from-green-100 to-white px-6 py-12">
        <div className="text-center space-y-6 max-w-xl">
          <h1 className="text-4xl font-bold text-green-600">You're All Set!</h1>
          <p className="text-xl text-gray-700">
            We've notified <strong>{visitorInfo.name}</strong> via{" "}
            <strong>{visitorInfo.email}</strong> to let them know you have arrived.
          </p>
          <p className="text-sm text-gray-500">Please wait in the lobby. Your host will be with you shortly.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-100 to-white px-6 py-12">
      <div className="bg-white shadow-xl rounded-2xl w-full max-w-md p-6 space-y-6">
        <h1 className="text-3xl font-bold text-center text-gray-800">Guest Check-In</h1>
        <div className="space-y-4">
          <label className="block font-medium text-gray-700">Upload QR Code <span className="text-red-500">*</span></label>
          <input
            type="file"
            accept="image/*"
            required
            onChange={(e) => handleQRChange(e.target.files?.[0] || null)}
            className="border rounded-lg p-2 w-full"
          />
          {qrPreviewUrl && (
            <div className="mt-2">
              <p className="text-sm text-gray-600 mb-1">Preview:</p>
              <img src={qrPreviewUrl} alt="QR Preview" className="w-full h-40 object-contain border rounded-md" />
            </div>
          )}

          <label className="block font-medium text-gray-700 mt-4">Take Your Picture <span className="text-red-500">*</span></label>
          <div className="space-y-2">
            <video ref={videoRef} className="rounded-md w-full h-48 object-cover bg-black" />
            <button
              type="button"
              onClick={startCamera}
              className="bg-blue-500 text-white py-1 px-3 rounded-lg text-sm"
            >
              Start Camera
            </button>
            <button
              type="button"
              onClick={capturePhoto}
              className="bg-green-500 text-white py-1 px-3 rounded-lg text-sm"
            >
              Capture Photo
            </button>
            {selfie && (
              <p className="text-green-600 text-sm">Selfie captured ✅</p>
            )}
          </div>
          <canvas ref={canvasRef} className="hidden" />
        </div>

        <button
          onClick={handleUpload}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg mt-6"
        >
          Check In
        </button>

        {message && <p className="text-center text-sm text-red-500">{message}</p>}
      </div>
    </div>
  );
};

export default QRCheckIn;
