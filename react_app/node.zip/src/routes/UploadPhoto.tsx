import { useRef, useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const UploadPhoto = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const location = useLocation();
  const navigate = useNavigate();

  const visitorInfo = location.state?.visitorInfo;

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      setMessage('Unable to access camera. Please check permissions.');
    }
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (video && canvas) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);

      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], 'photo.jpg', { type: 'image/jpeg' });
          setSelfie(file);
          setPreview(URL.createObjectURL(blob));
        }
      }, 'image/jpeg');
    }
  };

  const handleSubmit = async () => {
    if (!selfie) {
      return alert('Please take a photo first.');
    }

    const formData = new FormData();
    formData.append('photo', selfie);

    try {
      const res = await fetch('http://192.168.162.183:8080/upload-guest-photo', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        navigate('/checkin-success', { state: { visitorInfo } });
      } else {
        alert('Upload failed.');
      }
    } catch (err) {
      console.error(err);
      alert('Error uploading photo.');
    }
  };

  useEffect(() => {
    startCamera();
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-6">
      <div className="bg-white p-6 rounded-2xl shadow-md w-full max-w-md text-center space-y-6">
        <h2 className="text-xl font-semibold">Take Your Photo</h2>

        <video ref={videoRef} className="w-full h-64 object-cover rounded-md bg-black" />

        <canvas ref={canvasRef} className="hidden" />

        <button
          onClick={capturePhoto}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg"
        >
          Capture Photo
        </button>

        {preview && (
          <div className="mt-4">
            <p className="text-sm text-gray-600 mb-1">Preview:</p>
            <img src={preview} alt="Captured" className="w-full h-48 object-contain border rounded-md" />
          </div>
        )}

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
        >
          Submit
        </button>

        {message && <p className="text-red-500 text-sm">{message}</p>}
      </div>
    </div>
  );
};

export default UploadPhoto;
